namespace TrackerUIForms
{
    public partial class FrmTournamentDario : Form
    {
        public FrmTournamentDario()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}